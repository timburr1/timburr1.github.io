-- Insert SQL Rules Here 

UPDATE Language_EN_US SET Text = 'Isles' WHERE Tag = 'TXT_KEY_FEATURE_ATOLL';
UPDATE Language_EN_US SET Text = 'Isles' WHERE Tag = 'TXT_KEY_CIV5_FEATURES_ATOLL';
UPDATE Language_EN_US SET Text = 'An island is any piece of sub-continental land that is surrounded by water. Very small islands can be called isles, cays or keys.' WHERE Tag = 'TXT_KEY_CIV5_FEATURES_ATOLL_TEXT';